#NMK ChEG 848 2024

import os
import math
import csv

inFiles = ['atom_level_chemberta_results.csv' , 'char_level_chemberta_results.csv' , 'spe_level_chemberta_results.csv' , 'rf_atom_level_predictions.csv' , 'rf_char_level_predictions.csv' , 'rf_spe_level_predictions.csv' , 'xgb_atom_level_predictions.csv' , 'xgb_char_level_predictions.csv' ,'xgb_spe_level_predictions.csv']
outFiles = ['res_atom_level_chemberta_results.csv' , 'res_char_level_chemberta_results.csv' , 'res_spe_level_chemberta_results.csv' , 'res_rf_atom_level_predictions.csv' , 'res_rf_char_level_predictions.csv' , 'res_rf_spe_level_predictions.csv' , 'res_xgb_atom_level_predictions.csv' , 'res_xgb_char_level_predictions.csv' ,'res_xgb_spe_level_predictions.csv']


def dataRestore(inFileName , outFileName):
    masterName = "FULL_VALID_CAN_SMILES_DATASET_2.csv"
    file = open(masterName , 'r')
    lines = file.readlines()
    file.close()

    lines.pop(0)
    masterList = []

    for line in lines:
        #print(list)
        list = line.strip()
        list = list.split(',')
        masterList.append(list)
        
    #homo, lumo, gap, cansmiles, mw, thiophene , benzene , carboxylic acid , amide , imide , ether , ester , anhydride , nitrile , 3-bond C

    predictName = inFileName
    file = open(predictName , 'r')
    lines = file.readlines()
    file.close()

    lines.pop(0)
    predictionList = []

    for line in lines:
        #print(list)
        list = line.strip()
        list = list.split(',')
        predictionList.append(list)

    #ahomo, alumo, phomo, plumo

    j = 0 #predictionlist index
    k = 0

    bound = .0001

    for line in predictionList:
        ahomo = float(line[0])
        alumo = float(line[1])
        i = 0 #masterlist index
        
        
        for refLine in masterList:
            if (abs(abs(float(refLine[0])) - abs(ahomo)) < (abs(ahomo) * bound)) and (abs(abs(float(refLine[1])) - abs(alumo)) < (abs(alumo) * bound)):
            #if (refLine[0] == ahomo) and (refLine[1] == alumo):
                predictionList[j].append(refLine)
                #print(ahomo , alumo)
                #print(refLine)
                #print(masterList[i])
                #print(((abs(float(refLine[0])) - abs(ahomo))))
                #print((abs(ahomo) * bound))
                masterList.pop(i)
                k += 1
                break
                
            else:
                i += 1
                #print("No match on line " , i )

                
        #print("Line " , j , "completed")
        j += 1
        
    print(k , "matches found") 
     
    #outFileName = 'sample2.csv'
    outFile = open(outFileName , 'w')
    #outFile.write('can_smiles,thiophene,benzene,carboxylic_acid,amide,imide,ether,ester,anhydride,nitrile,3_bond_c\n')
    csvwriter = csv.writer(outFile, delimiter=',', quotechar='|', quoting=csv.QUOTE_MINIMAL)

    i = 0
    for line in predictionList:
        csvwriter.writerow(line)
        #print('line' , i , 'written')
        i += 1
        
    outFile.close()



    outFile = open(outFileName , 'r')
    lines = outFile.readlines()
    outFile.close()

    outFileList = []

    for line in lines:
        #print(list)
        list = line.strip()
        list = list.split(',')
        outFileList.append(list)
        
    outFile = open(outFileName , 'w')
    #outFile.write('can_smiles,thiophene,benzene,carboxylic_acid,amide,imide,ether,ester,anhydride,nitrile,3_bond_c\n')
    csvwriter = csv.writer(outFile, delimiter=',', quotechar='|', quoting=csv.QUOTE_MINIMAL)

    i = 0
    for line in outFileList:
        j = 0
        for item in line:
            if 1 == 1:
                x = item.replace('|' , '')
                x = x.replace("'" , "")
                x = x.replace("[" , "")
                x = x.replace("]" , "")
                line[j] = x
            j += 1
        csvwriter.writerow(line)
        #print('line' , i , 'written')
        i += 1
        
    outFile.close()
    
l = 0
while l < len(inFiles):
    dataRestore(inFiles[l] , outFiles[l])
    print('completed' , inFiles[l])
    l += 1
