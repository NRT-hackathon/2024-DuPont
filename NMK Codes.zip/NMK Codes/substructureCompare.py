#NMK ChEG 848 2024

import os
import math
import csv
import rdkit
from rdkit import Chem

#directory = os.getcwd()
#os.chdir('./3384184')

name = "FULL_VALID_CAN_SMILES_DATASET_2.csv"
file = open(name , 'r')
lines = file.readlines()
file.close()

#print(lines)

canSmiles = []

for line in lines:
    #print(list)
    list = line.strip()
    print(list)
    list = list.split(',')
    print(list)
    canSmiles.append(list[3])

substructures = ['c1ccsc1' , 'c1ccccc1' , 'C(=O)O' , 'C(=O)N' , 'C(=O)NC(=O)' , 'COC' , 'COC(=O)' , 'C(=O)OC(=O)' , 'C#N' , 'C#C']
#thiophene , benzene , carboxylic acid , amide , imide , ether , ester , anhydride , nitrile , 3-bond C

dataTable = []

i = 0
while i < len(canSmiles):
    line = []
    line.append(canSmiles[i])
    for substructure in substructures:
        try:
            smile = Chem.MolFromSmiles(canSmiles[i])
            group = Chem.MolFromSmiles(substructure)
            print(smile.HasSubstructMatch(group))
            if smile.HasSubstructMatch(group):
                line.append('1')
            else:
                line.append('0')
        except AttributeError:
            line.append(-1)
    print('line' , i , 'complete')
    print(line)
    dataTable.append(line)
    i += 1
    
outFileName = 'MasterList.csv'
outFile = open(outFileName , 'w')
outFile.write('can_smiles,thiophene,benzene,carboxylic_acid,amide,imide,ether,ester,anhydride,nitrile,3_bond_c\n')
csvwriter = csv.writer(outFile, delimiter=',', quotechar='|', quoting=csv.QUOTE_MINIMAL)

i = 0
for line in dataTable:
    csvwriter.writerow(line)
    print('line' , i , 'written')
    i += 1
    
outFile.close()    
