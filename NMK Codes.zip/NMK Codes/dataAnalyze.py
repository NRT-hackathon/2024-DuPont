#NMK ChEG 848 2024

import os
import math
import csv
import numpy as np

inFiles = ['res_atom_level_chemberta_results.csv' , 'res_char_level_chemberta_results.csv' , 'res_spe_level_chemberta_results.csv' , 'res_rf_atom_level_predictions.csv' , 'res_rf_char_level_predictions.csv' , 'res_rf_spe_level_predictions.csv' , 'res_xgb_atom_level_predictions.csv' , 'res_xgb_char_level_predictions.csv' ,'res_xgb_spe_level_predictions.csv']
outFiles = ['sum_atom_level_chemberta_results.csv' , 'sum_char_level_chemberta_results.csv' , 'sum_spe_level_chemberta_results.csv' , 'sum_rf_atom_level_predictions.csv' , 'sum_rf_char_level_predictions.csv' , 'sum_rf_spe_level_predictions.csv' , 'sum_xgb_atom_level_predictions.csv' , 'sum_xgb_char_level_predictions.csv' ,'sum_xgb_spe_level_predictions.csv']

def dataAnalyze(inFileName , outFileName):
    #homoact, lumoact, homop , lumop , homoact, lumoaact, gap, cansmiles, mw, thiophene , benzene , carboxylic acid , amide , imide , ether , ester , anhydride , nitrile , 3-bond C

    file = open(inFileName , 'r')
    lines = file.readlines()
    file.close()

    dataList = []
    sumHOMO = 0
    sumLUMO = 0
    errorCount = 0
    
    for line in lines:
        #print(list)
        list = line.strip()
        list = list.split(',')
        try:
            test = list[9]
            
            indices = [0 , 1 , 2 , 3]
            for i in indices:
                list[i] = float(list[i])

            indices = [9 , 10 , 11 , 12 , 13 , 14 , 15 , 16 , 17 , 18]
            for i in indices:
                list[i] = int(list[i])
                
            sumHOMO += list[0]
            sumLUMO += list[1]           
            dataList.append(list)
            
        except IndexError:
            errorCount += 1
        
    meanHOMO = sumHOMO / len(dataList)    
    meanLUMO = sumLUMO / len(dataList)    
        
    #totals to be summed. Indices are as follows below:
    #overall, thiophene , benzene , carboxylic acid , amide , imide , ether , ester , anhydride , nitrile , 3-bond C
    indices = [1 , 2 , 3 , 4 , 5 , 6 , 7 , 8 , 9 , 10]
    count = np.zeros(11)
    absErrorHOMO = np.zeros(11)
    absErrorLUMO = np.zeros(11)
    sqErrorHOMO = np.zeros(11)
    sqErrorLUMO = np.zeros(11)
    squaresHOMO = np.zeros(11)
    squaresLUMO = np.zeros(11)
    
    j = 0
    
    #iterate for every line of data
    for line in dataList: 
        count[0] += 1
        absErrorHOMO[0] += abs(line[0] - line[2])
        absErrorLUMO[0] += abs(line[1] - line[3])
        sqErrorHOMO[0] += (abs(line[0] - line[2]))**2
        sqErrorLUMO[0] += (abs(line[1] - line[3]))**2
        squaresHOMO[0] += (line[0] - meanHOMO)**2
        squaresLUMO[0] += (line[1] - meanLUMO)**2
        
        #iterate for every category we care about        
        for i in indices:
            if (line[(i + 8)] == 1):
                count[i] += 1
                absErrorHOMO[i] += abs(line[0] - line[2])
                absErrorLUMO[i] += abs(line[1] - line[3])
                sqErrorHOMO[i] += (abs(line[0] - line[2]))**2
                sqErrorLUMO[i] += (abs(line[1] - line[3]))**2
                squaresHOMO[i] += (line[0] - meanHOMO)**2
                squaresLUMO[i] += (line[1] - meanLUMO)**2
        #print('line ' , j , 'completed')
        j += 1
                
    mseHOMO = np.zeros(11) 
    mseLUMO = np.zeros(11)
    maeHOMO = np.zeros(11)
    maeLUMO = np.zeros(11)
    r2HOMO = np.zeros(11)
    r2LUMO = np.zeros(11)
    
    indices = [0 , 1 , 2 , 3 , 4 , 5 , 6 , 7 , 8 , 9 , 10]
    for i in indices:
        if count[i] == 0:
            mseHOMO[i] = 0
            mseLUMO[i] = 0
            maeHOMO[i] = 0
            maeLUMO[i] = 0
            r2HOMO[i] = 0
            r2LUMO[i] = 0            
        else:
            mseHOMO[i] = sqErrorHOMO[i] / count[i]
            mseLUMO[i] = sqErrorLUMO[i] / count[i]
            maeHOMO[i] = absErrorHOMO[i] / count[i]
            maeLUMO[i] = absErrorLUMO[i] / count[i]
            r2HOMO[i] = 1 - ((count[i] * mseHOMO[i]) / squaresHOMO[i])
            r2LUMO[i] = 1 - ((count[i] * mseLUMO[i]) / squaresLUMO[i])
    
    nameList = ['overall' , 'thiophene' , 'benzene' , 'carboxylic_acid' , 'amide' , 'imide' , 'ether' , 'ester' , 'anhydride' , 'nitrile' , '3_bond_c']
    outFile = open(outFileName , 'w')
    outFile.write(',count,mseHOMO,mseLUMO,maeHOMO,maeLUMO,r2HOMO,r2LUMO\n')
    for i in indices:
        outFile.write(repr(nameList[i]) + ',' + repr(count[i]) + ',' + repr(mseHOMO[i]) + ',' + repr(mseLUMO[i]) + ',' + repr(maeHOMO[i]) + ',' + repr(maeLUMO[i]) + ',' + repr(r2HOMO[i]) + ',' + repr(r2LUMO[i]) + '\n')
    
    outFile.write('Error lines:' + ',' + repr(errorCount))
    #outFile.write('overall,thiophene,benzene,carboxylic_acid,amide,imide,ether,ester,anhydride,nitrile,3_bond_c\n')
    #csvwriter = csv.writer(outFile, delimiter=',', quotechar='|', quoting=csv.QUOTE_MINIMAL)

    outFile.close()
 
#dataAnalyze('res_atom_level_chemberta_results.csv' , 'sample.csv') 

l = 0
while l < len(inFiles):
    dataAnalyze(inFiles[l] , outFiles[l])
    print('completed' , inFiles[l])
    l += 1
